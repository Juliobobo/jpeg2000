Le fichier 'globals.h' définit la taille de l'image, l'écriture ou non de messages de DEBUG et le nom du fichier source à tester.

Les fichiers ‘Main_Decop_Ond.cpp’ et ‘Main_Decop_Ond.h’ correspondent à la fonction décompression.

Les fichiers ‘Main_Trans_Ond.cpp’ et ‘Main_Trans_Ond.h’ correspondent à la fonction de compresser l'image par ondelette.

Le fichier ‘TB_Trans_Ond.cpp’ contient la fonction main.
