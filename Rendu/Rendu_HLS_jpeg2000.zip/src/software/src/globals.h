#ifndef GLOBALS_H
#define GLOBALS_H

//#define DEBUG

#define WIDTH_IMAGE  320
#define HEIGHT_IMAGE 240

#define IMAGE_SOURCE "image/lena2.pgm"

#endif
