'CPP_for_CatapultC' contient les sources C++ utuilisées dans Catapult pour générer le fichier EDIF nécessaires à la synthèse de la tranformation en Ondelettes (pour les générer, suivre le manuel utilisateur dans ../doc/UserManual.pdf).

'software' contient les fichiers réalisant la transformation en ondelettes et sa décompression.

'vhd' contient les sources vhd nécessaires à la synthèse de la transformation en ondelettes.
